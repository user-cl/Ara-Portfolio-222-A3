﻿using ChessGameView;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChessGameView
{
    public static class SaveFile
    {
        public static object[] savePosArray = new object[]
           {
            // (0, 0) -> (2, 0)
            Part.Empty,
            Part.Empty,
            Part.Empty,
            // (0, -1) -> (2, -1)
            Part.Empty,
            Part.Empty,
            Part.Empty,
            // (0, -2) -> (2, -2)
            Part.Empty,
            Part.Empty,
            Part.Empty,
           };
    }
}
