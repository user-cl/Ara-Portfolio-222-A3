﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChessGameView
{

    public class Filer : IFiler
    {
        // Save game file
        public void Save(object[][] currentGridArray)
        {
            // Loop through currentGridArray in use by player
            for (int i = 0; i < SaveFile.savePosArray.Length; ++i)
            {
                // Assign each value to SaveFile.savePosArray
                SaveFile.savePosArray[i] = (Part)currentGridArray[i][1];
            }
        }
        // Load game file
        public object[][] Load(object[][] currentGridArray)
        {
            // Get positions from loaded position array (LoadFile.cs)
            object[] loadPosArray = LoadFile.loadPosArray;

            // Loop through loadPosArray, assign positions to currentGridArray
            for (int i = 0; i < loadPosArray.Length; ++i)
            {
                currentGridArray[i][1] = loadPosArray[i];
            }
            return currentGridArray;
        }
    }


}