﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace ChessGameView
{
    public partial class ChessGameForm : Form
    {
        public string inTextVal = null;
        public event EventHandler clickButton;

        public ChessGameForm()
        {
            // load form parts
            InitializeComponent();
            // textBox1 config
                // set minimum size to prevent under-stretching
                this.MinimumSize = new Size(700, 500);
                textBox1.ReadOnly = true;
            // load form
            Load += ChessGameForm_load;
        }

        // on load
        public void ChessGameForm_load(object sender, EventArgs e)
        {
            // make controller
            IGame game = new Game();
            IFileable fileable = new Fileable();
            IFiler filer = new Filer();
            var chessGameController = new ChessGameController(game, fileable, filer, this);
            // get the program started
            ConvertConsoleWrite("Welcome to The Chess Maze Game!");
            ConvertConsoleWrite("Press [send] to start!");
        }

        // OUTPUT TRANSLATORS
        // write
        public void ConvertConsoleWrite(string text)
        {
            textBox1.AppendText(text + Environment.NewLine);
        }

        // clear
        public void ConvertConsoleClear()
        {
            textBox1.Clear();
        }

        // send button click to update text val
        private void button2_Click(object sender, EventArgs e)
        {
            // update textbox value, activate handler
            inTextVal = inText.Text.Trim();
            clickButton?.Invoke(this, EventArgs.Empty);
        }
    }
}
