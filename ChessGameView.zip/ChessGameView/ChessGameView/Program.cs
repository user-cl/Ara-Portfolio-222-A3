﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChessGameView
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // make form
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            ChessGameForm myForm = new ChessGameForm();
            // run form
            Application.Run(myForm);
        }
    }



}
