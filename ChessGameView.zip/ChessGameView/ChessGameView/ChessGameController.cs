﻿using ChessGameView;
using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChessGameView
{

    public class ChessGameController
    {
        // instances
        private readonly IGame _game;
        private readonly IFileable _fileable;
        private readonly IFiler _filer;
        private readonly ChessGameForm _form;

        // Enum
        public Direction moveDirection;
        public Part oldPart;
        public Part newPart;

        // string
        public string gridOut;
        public string userInput;
        public string userOptions = "Enter for:"+Environment.NewLine + "[1] Move"+Environment.NewLine+ "[2] Undo"+Environment.NewLine+"[3] Save"+Environment.NewLine+"[4] Reset" + Environment.NewLine;

        // int
        public int columnCount;
        public int rowCount;
        public int moveCount;
        public int userOutput;
        public int winCount;
        public int loseCount;
        public int oldPosIndex;
        public int newPosIndex;

        // type (int, int)
        public (int, int) posOld;
        public (int, int) posNew;

        // bool
        public bool contGame = true;
        public bool finishCheck = false;
        public bool playerAns;

        // dictionaries
        public Dictionary<Part, string> chessSymbols = new Dictionary<Part, string>
            {
                {Part.Empty, $"[ {(char)Part.Empty} ]"},
                {Part.King, $"[ {(char)Part.King} ]"},
                {Part.Rook, $"[ {(char)Part.Rook} ]"},
                {Part.Bishop, $"[ {(char)Part.Bishop} ]"},
                {Part.Knight, $"[ {(char)Part.Knight} ]"},
                {Part.PlayerOnKing, $"[ {(char)Part.PlayerOnKing} ]"},
                {Part.PlayerOnRook, $"[ {(char)Part.PlayerOnRook} ]"},
                {Part.PlayerOnBishop, $"[ {(char)Part.PlayerOnBishop} ]"},
                {Part.PlayerOnKnight, $"[ {(char)Part.PlayerOnKnight} ]"}
            };

        // arrays
        public List<(int, int)> moveTuples = new List<(int, int)> { };

        // Current player position; there is always only one element of [Tuple Coordinates, Part]
        public object[][] currentPlayerPos = new object[][]
        {
                new object[] { (0, 0), Part.Empty},
        };
        // Current player moves
        public object[][] currentPlayerMoves = new object[][] { };
        // Current grid
        public object[][] currentGridArray = new object[][]
        {
                new object[] { (0, 0), Part.Empty},
                new object[] { (1, 0), Part.Empty},
                new object[] { (2, 0), Part.Empty},
                new object[] { (0, -1), Part.Empty},
                new object[] { (1, -1), Part.Empty},
                new object[] { (2, -1), Part.Empty},
                new object[] { (0, -2), Part.Empty},
                new object[] { (1, -2), Part.Empty},
                new object[] { (2, -2), Part.Empty}
        };

        // CONTROLLER STATES
            // view start - starts true by default
        public bool introState = true;
                // view action - four options
            public bool actionState = false;
            public bool actionChoose = false;
                    //  move
            public bool actionStateMove = false;
                    // undo
            public bool actionStateUndo = false;
                    // save
            public bool actionStateSave = false;
                    // reset
            public bool actionStateReset = false;
            // view end
        public bool endState;

        // VALUE PASSED BY VIEW
        public string getTextVal = null;

        // VALUE PASSED TO VIEW
        public string pieceImageUrlBishop = "C:\\Temp\\222\\ChessGameView\\ChessGameView\\piece-bishop.png";
        public string pieceImageUrlKnight = "C:\\Temp\\222\\ChessGameView\\ChessGameView\\piece-knight.png";
        public string pieceImageUrlRook = "C:\\Temp\\222\\ChessGameView\\ChessGameView\\piece-rook.png";
        public string pieceImageUrlKing = "C:\\Temp\\222\\ChessGameView\\ChessGameView\\piece-king.png";


        // Controller
        public ChessGameController(IGame game, IFileable fileable, IFiler filer, ChessGameForm form)
        {
            _game = game;
            _fileable = fileable;
            _filer = filer;
            _form = form;
            // event subscribe
            _form.clickButton += RedirectButtonClick;
        }

        // Controller event for program
        private void RedirectButtonClick(object sender, EventArgs e)
        {
            // update current text val
            getTextVal = _form.inTextVal;

            // Update current player piece
            var playerpos = (Part)currentPlayerPos[0][1];
            //  King
            if (playerpos == Part.PlayerOnKing)
            {
                _form.pictureBox1.Load(pieceImageUrlKing);
            }
            // Bishop
            else if (playerpos == Part.PlayerOnBishop)
            {
                _form.pictureBox1.Load(pieceImageUrlBishop);
            }
            // Rook
            else if (playerpos == Part.PlayerOnRook)
            {
                _form.pictureBox1.Load(pieceImageUrlRook);
            }
            // Knight
            else if (playerpos == Part.PlayerOnKnight)
            {
                _form.pictureBox1.Load(pieceImageUrlKnight);
            }

            // determine state based on getTextVal

            // IF INTRO
            if (introState == true && actionState == false && actionChoose == false && endState == false)
            {
                // Load()
                _filer.Load(currentGridArray);

                // GetColumnCount()
                columnCount = _fileable.GetColumnCount(columnCount, currentGridArray);

                // GetRowCount()
                rowCount = _fileable.GetRowCount(rowCount, currentGridArray);

                // Activate action state, reset loop
                CloseIntro();
                OpenAction();
                RedirectButtonClick(this, EventArgs.Empty);

            }

            // ELSE IF ACTION
            else if (introState == false && actionState == true && actionChoose == false && endState == false)
            {
                // ReadGrid()
                currentPlayerPos = _fileable.ReadGrid(currentPlayerPos, currentGridArray);

                // GetMoves()
                currentPlayerMoves = _game.GetMoves
                (
                moveTuples,
                rowCount,
                currentPlayerMoves,
                currentPlayerPos,
                posOld,
                currentGridArray
                );

                // IsFinished()
                if (_game.IsFinished(currentPlayerPos, currentPlayerMoves))
                {
                    // GetWinCount()
                    winCount = _game.GetWinCount(winCount, currentPlayerPos);

                    // GetLoseCount()
                    loseCount = _game.GetLoseCount(loseCount, currentPlayerMoves, currentPlayerPos);
                    _form.ConvertConsoleWrite($"Wins: {winCount}" + Environment.NewLine + $"Losses: {loseCount}" + Environment.NewLine + $"Moves: {moveCount}");

                    // Get Reset Choice 
                    MessageBox.Show("Game over.");
                    userOutput = -1;
                    do
                    {
                        // get userOutput
                        userInput = Microsoft.VisualBasic.Interaction.InputBox("Play Again? (Y/N)", "Input", "");
                        // if Y or N, valid and can stop while loop
                        if (userInput.Trim() == "Y" || userInput == "N")
                        {
                          userOutput = 1;
                        }
                        // Else loop until output correct
                    } while (userOutput == -1);

                    // If answer is N, stop game entirely
                    if (userInput == "N")
                    {
                        // reset everything and take player to end door
                        MessageBox.Show("Game Stopped.");
                        CloseAction();
                        CloseIntro();
                        OpenEnd();
                        _form.ConvertConsoleClear();
                        _form.inTextVal = null;
                        RedirectButtonClick(this, EventArgs.Empty);
                    }
                    // Else if Y, continue
                    else if (userInput == "Y")
                    {
                        MessageBox.Show("Next Round!");
                        // wipe screen, reset all doors to start but keep scores
                        CloseAction();
                        OpenIntro();
                        _form.ConvertConsoleClear();
                        _form.inTextVal = null;
                        RedirectButtonClick(this, EventArgs.Empty);
                    }
                        
                }
                // else continue if game not won/lost.
                    // ++ moveCount
                    moveCount = _game.GetMoveCount(moveCount, currentGridArray);

                    // reset player input, function; open door to action choose
                    CloseAction();
                    OpenActionChoose();
                    _form.inTextVal = null;
                    RedirectButtonClick(this, EventArgs.Empty);
            }

            // ELSE IF ACTION CHOOSE
            else if (introState == false && actionState == false && actionChoose == true && endState == false)
            {

                // if (1-4) inclusive, continue
                if (getTextVal == "1" || getTextVal == "2" || getTextVal == "3" || getTextVal == "4")
                {
                    // continue, case system for opening which actionState (3/4 remaining are closed)
                    switch (getTextVal)
                    {
                        case "1":
                            OpenActionMove();
                            CloseActionUndo();
                            CloseActionSave();
                            CloseActionReset();
                            break;
                        case "2":
                            CloseActionMove();
                            OpenActionUndo();
                            CloseActionSave();
                            CloseActionReset();
                            break;
                        case "3":
                            CloseActionMove();
                            CloseActionUndo();
                            OpenActionSave();
                            CloseActionReset();
                            break;
                        case "4":
                            CloseActionMove();
                            CloseActionUndo();
                            CloseActionSave();
                            OpenActionReset();
                            break;
                    }

                    // 1 - if action move state
                    if (actionStateMove == true && actionStateUndo == false && actionStateSave == false && actionStateReset == false)
                    {
                        _form.ConvertConsoleWrite("Enter move:");

                        // Show player moves
                        for (int i = 0; i < currentPlayerMoves.Length; ++i)
                        {
                            // Output choice to user
                            _form.ConvertConsoleWrite($"[{i}] from {((int, int))currentPlayerPos[0][0]} to {((int, int))currentPlayerMoves[i][0]}");
                        }

                        // Loop player until correct choice made
                            // reset prior userOutput
                            userOutput = -1;
                            do
                            {
                                // get userOutput
                                userInput = Microsoft.VisualBasic.Interaction.InputBox("Enter Move Choice:", "Input", "");
                                // if int within range
                                if (int.TryParse(userInput, out int commandNum))
                                {
                                    // Valid, stop while loop
                                    if (commandNum >= 0 && commandNum < currentPlayerMoves.Length)
                                    {
                                        userOutput = commandNum;
                                    }
                                }
                                // Else loop until output correct
                            } while (userOutput == -1);

                        // GetOldPosition()
                        posOld = _game.GetOldPosition(currentPlayerPos);
                        // GetNewPosition()
                        posNew = _game.GetNewPosition(userOutput, currentPlayerMoves);
                        // GetDirection()
                        _form.ConvertConsoleClear();
                        moveDirection = _game.GetDirection(posOld, posNew, moveDirection);
                        // Move()
                        _game.Move(posOld, posNew, currentGridArray, oldPosIndex, newPosIndex, oldPart, newPart);

                        MessageBox.Show($"You moved {moveDirection} from {posOld} to {posNew}.");

                        
                        // The action is done, close all doors and go back to Action
                        OpenAction();
                        CloseActionMove();
                        CloseActionChoose();
                        _form.inTextVal = null;
                        RedirectButtonClick(this, EventArgs.Empty);

                    }

                    // 2 - else if action undo state
                    else if (actionStateMove == false && actionStateUndo == true && actionStateSave == false && actionStateReset == false)
                    {
                        _form.ConvertConsoleWrite(_game.Undo(posOld, posNew, currentGridArray, oldPosIndex, newPosIndex, moveCount, oldPart, newPart, currentPlayerPos));
                        // The action is done, close all doors and go back to Action
                        OpenAction();
                        CloseActionMove();
                        CloseActionChoose();
                        _form.inTextVal = null;
                        RedirectButtonClick(this, EventArgs.Empty);
                    }

                    // 3 - else if action save state
                    else if (actionStateMove == false && actionStateUndo == false && actionStateSave == true && actionStateReset == false)
                    {
                        _form.ConvertConsoleClear();
                        _filer.Save(currentGridArray);
                        // The action is done, close all doors and go back to Action
                        OpenAction();
                        CloseActionMove();
                        CloseActionChoose();
                        _form.inTextVal = null;
                        RedirectButtonClick(this, EventArgs.Empty);
                        // show evidence of overwrite
                        var showSave = "";
                        for (int i = 0; i < SaveFile.savePosArray.Length; ++i)
                        {
                            showSave += $"{SaveFile.savePosArray[i]}" + Environment.NewLine;
                        }
                        MessageBox.Show($"You saved your progress." + Environment.NewLine + showSave);
                    }

                    // 4 - else if action reset state
                    else if (actionStateMove == false && actionStateUndo == false && actionStateSave == false && actionStateReset == true)
                    {
                        // Restart()
                        _form.ConvertConsoleClear();
                        _game.Restart(currentGridArray, _filer);
                        // The action is done, close all doors and go back to Action
                        OpenAction();
                        CloseActionMove();
                        CloseActionChoose();
                        _form.inTextVal = null;
                        RedirectButtonClick(this, EventArgs.Empty);
                    }
                }

                // else bad, refresh
                else {
                    // ShowGrid()
                    _form.ConvertConsoleClear();
                    _form.ConvertConsoleWrite(_game.ShowGrid(rowCount, gridOut, currentGridArray, _fileable, chessSymbols));
                    _form.ConvertConsoleWrite(userOptions);
                }
            }

            // else if end state
            else if (introState == false && actionState == false && actionChoose == false && endState == true)
            {
                _form.ConvertConsoleWrite("Thanks for Playing! :)");
            }
        }

        // traffic manager functions
        // open
        public void OpenIntro()
        {
            introState = true;
        }
        public void CloseIntro()
        {
            introState = false;
        }
        // action
        public void OpenAction()
        {
            actionState = true;
        }
        public void CloseAction()
        {
            actionState = false;
        }
        // action choose
        public void OpenActionChoose()
        {
            actionChoose = true;
        }
        public void CloseActionChoose()
        {
            actionChoose = false;
        }
        // action choose 
        public void OpenActionMove()
        {
            actionStateMove = true;
        }
        public void CloseActionMove()
        {
            actionStateMove = false;
        }
        // action - undo
        public void OpenActionUndo()
        {
            actionStateUndo = true;
        }
        public void CloseActionUndo()
        {
            actionStateUndo = false;
        }
        // action - save
        public void OpenActionSave()
        {
            actionStateSave = true;
        }
        public void CloseActionSave()
        {
            actionStateSave = false;
        }
        // action reset
        public void OpenActionReset()
        {
            actionStateReset = true;
        }
        public void CloseActionReset()
        {
            actionStateReset = false;
        }
        // end
        public void OpenEnd()
        {
            endState = true;
        }
        public void CloseEnd()
        {
            endState = false;
        }

       
        
    }
}