﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChessGameView
{

    public class Fileable : IFileable
    {
        // get player position
        public object[][] ReadGrid(object[][] currentPlayerPos, object[][] currentGridArray)
        {
            // Loop through currentGridArray, Get player position
            for (int i = 0; i < currentGridArray.Length; ++i)
            {
                // See if player on:
                switch (currentGridArray[i][1])
                {

                    // assign new coordinates + part to currentPlayerPos
                    // King
                    case Part.PlayerOnKing:
                        currentPlayerPos[0][0] = currentGridArray[i][0];
                        currentPlayerPos[0][1] = currentGridArray[i][1];
                        break;
                    // Rook
                    case Part.PlayerOnRook:
                        currentPlayerPos[0][0] = currentGridArray[i][0];
                        currentPlayerPos[0][1] = currentGridArray[i][1];
                        break;
                    // Bishop
                    case Part.PlayerOnBishop:
                        currentPlayerPos[0][0] = currentGridArray[i][0];
                        currentPlayerPos[0][1] = currentGridArray[i][1];
                        break;
                    // Knight
                    case Part.PlayerOnKnight:
                        currentPlayerPos[0][0] = currentGridArray[i][0];
                        currentPlayerPos[0][1] = currentGridArray[i][1];
                        break;
                }
            }
            // update current pos, return to user
            return currentPlayerPos;
        }

        // Returns part value of given (x, y) coordinate
        public Part WhatsAt(int row, int column, object[][] currentGridArray)
        {
            // Loop through currentGridArray and find piece associated with position
            for (int i = 0; i < currentGridArray.Length; ++i)
            {
                // Get current tuple coordinates
                var currentTuple = ((int, int))currentGridArray[i][0];
                // If both X/Y are equivalent, return associated position
                if (currentTuple.Item1 == row && currentTuple.Item2 == column)
                {
                    // Convert found value to part type, return value
                    var posPart = (Part)currentGridArray[i][1];
                    return posPart;
                }
            }
            // Else throw exception; no position found.
            throw new ArgumentException("ERROR: Position not present.");

        }
        // Count columns
        public int GetColumnCount(int columnCount, object[][] currentGridArray)
        {
            // Reset columnCount
            columnCount = 0;
            // Loop through currentGridArray, count all columns 
            for (int i = 0; i < currentGridArray.Length; ++i)
            {
                // Get current tuple coordinates
                var currentTuple = ((int, int))currentGridArray[i][0];
                // If coordinates are A >= 0, and B == 0, ++columnCount
                if (currentTuple.Item1 >= 0 && currentTuple.Item2 == 0)
                {
                    columnCount++;
                };
            }
            // return updated variable
            return columnCount;
        }
        // Count rows
        public int GetRowCount(int rowCount, object[][] currentGridArray)
        {
            // Reset rowCount
            rowCount = 0;
            // Loop through currentGridArray, count all rows
            for (int i = 0; i < currentGridArray.Length; ++i)
            {
                // Get current tuple coordinates
                var currentTuple = ((int, int))currentGridArray[i][0];

                // If coordinates are A >= 0, and B == 0, ++rowCount
                if (currentTuple.Item1 == 0 && currentTuple.Item2 <= 0)
                {
                    rowCount++;
                };

            }
            // return updated variable
            return rowCount;
        }
    }



}