﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChessGameView
{
    public interface IFileable
    {
        // Get part of given position on given grid
        Part WhatsAt(int row, int column, object[][] currentGridArray);

        // Get columnCount of given grid
        int GetColumnCount(int columnCount, object[][] currentGridArray);

        // Get rowCount of given grid
        int GetRowCount(int rowCount, object[][] currentGridArray);

        // Get player position, inform user
        object[][] ReadGrid(object[][] currentPlayerPos, object[][] currentGridArray);

    }
}
