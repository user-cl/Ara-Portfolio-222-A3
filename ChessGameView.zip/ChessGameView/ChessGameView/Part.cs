﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChessGameView
{
    public enum Part
    {
        Empty = (int)'E',
        King = (int)'K',
        Rook = (int)'R',
        Bishop = (int)'B',
        Knight = (int)'N',
        PlayerOnKing = (int)'k', // If the player is on king, they win		
                                 // Positions where the player is "playing as" rook/bishop/knight
        PlayerOnRook = (int)'r',
        PlayerOnBishop = (int)'b',
        PlayerOnKnight = (int)'n'

    }
}
