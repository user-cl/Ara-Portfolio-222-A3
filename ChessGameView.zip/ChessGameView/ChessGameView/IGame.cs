﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Security.Cryptography.X509Certificates;
using ChessGameView;

namespace ChessGameView
{
    public interface IGame
    {

        // Get old player position
        (int, int) GetOldPosition(object[][] currentPlayerPos);
        // Get new player position
        (int, int) GetNewPosition(int userOutput, object[][] currentPlayerMoves);
        // Get player direction
        Direction GetDirection((int, int) posOld, (int, int) posNew, Direction moveDirection);

        // Get possible player moves for player turn
        object[][] GetMoves(
            List<(int, int)> moveTuples,
            int rowCount,
            object[][] currentPlayerMoves,
            object[][] currentPlayerPos,
            (int, int) posOld,
            object[][] currentGridArray
            );

        // Move player position from old -> new location
        void Move(
            (int, int) posOld,
            (int, int) posNew,
            object[][] currentGridArray,
            int oldPosIndex,
            int newPosIndex,
            Part oldPart,
            Part newPart);

        // Count player moves
        int GetMoveCount(int moveCount, object[][] currentGridArray);

        // Count player wins
        int GetWinCount(int winCount, object[][] currentPlayerPos);

        // Count player losses
        int GetLoseCount(int loseCount, object[][] currentPlayerMoves, object[][] currentPlayerPos);

        // Undo last move
        string Undo(
            (int, int) posOld,
            (int, int) posNew,
            object[][] currentGridArray,
            int oldPosIndex,
            int newPosIndex,
            int moveCount,
            Part oldPart,
            Part newPart,
            object[][] currentPlayerPos
            );

        // Restart game
        object[][] Restart(object[][] currentGridArray, IFiler filer);

        // Check if game finished
        bool IsFinished(object[][] currentPlayerPos, object[][] currentPlayerMoves);

        // Get grid output
        string ShowGrid(int rowCount, string gridOut, object[][] currentGridArray, IFileable fileable, Dictionary<Part, string> chessSymbols);
    }
}
