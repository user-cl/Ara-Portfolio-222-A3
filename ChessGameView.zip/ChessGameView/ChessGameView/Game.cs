﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

using System;
using System.Collections.Generic;
using ChessGameView;

namespace ChessGameView
{

    public class Game : IGame
    {
        // Get old player position
        public (int, int) GetOldPosition(object[][] currentPlayerPos)
        {
            return ((int, int))currentPlayerPos[0][0];
        }
        // Get new player position
        public (int, int) GetNewPosition(int userOutput, object[][] currentPlayerMoves)
        {
            return ((int, int))currentPlayerMoves[userOutput][0];
        }

        // Get player direction
        public Direction GetDirection((int, int) posOld, (int, int) posNew, Direction moveDirection)
        {
            // Create x/y values for both positions
            var oldX = posOld.Item1;
            var oldY = posOld.Item2;
            var newX = posNew.Item1;
            var newY = posNew.Item2;
            // conditionals for finding direction
            // left
            if (newX < oldX && newY == oldY)
            {
                moveDirection = Direction.Left;
            }
            // right
            else if (newX > oldX && newY == oldY)
            {
                moveDirection = Direction.Right;
            }
            // upLeft
            else if (newX < oldX && newY > oldY)
            {
                moveDirection = Direction.UpLeft;
            }
            // Up
            else if (newX == oldX && newY > oldY)
            {
                moveDirection = Direction.Up;
            }
            // upRight
            else if (newX > oldX && newY > oldY)
            {
                moveDirection = Direction.UpRight;
            }
            // DownLeft
            else if (newX < oldX && newY < oldY)
            {
                moveDirection = Direction.DownLeft;
            }
            // Down
            else if (newX == oldX && newY < oldY)
            {
                moveDirection = Direction.Down;
            }
            // DownRight
            else if (newX > oldX && newY < oldY)
            {
                moveDirection = Direction.DownRight;
            }
            // Return updated value
            return moveDirection;
        }

        // Get possible player moves for player turn
        public object[][] GetMoves(
            List<(int, int)> moveTuples,
            int rowCount,
            object[][] currentPlayerMoves,
            object[][] currentPlayerPos,
            (int, int) posOld,
            object[][] currentGridArray
            )
        {
            // update posOld
            posOld = ((int, int))currentPlayerPos[0][0];

            // Reset
            currentPlayerMoves = new object[][] { };

            // Reset
            moveTuples = new List<(int, int)> { };

            // Identify player piece
            switch (currentPlayerPos[0][1])
            {
                // Is Knight
                case Part.PlayerOnKnight:

                    // add values
                    // up: left
                    moveTuples.Add(((posOld.Item1 - 1), (posOld.Item2 + 2)));

                    // up: right
                    moveTuples.Add(((posOld.Item1 + 1), (posOld.Item2 + 2)));

                    // left: up
                    moveTuples.Add(((posOld.Item1 - 2), (posOld.Item2 + 1)));

                    // left: down
                    moveTuples.Add(((posOld.Item1 - 2), (posOld.Item2 - 1)));

                    // right: up
                    moveTuples.Add(((posOld.Item1 + 2), (posOld.Item2 + 1)));

                    // right: down
                    moveTuples.Add(((posOld.Item1 + 2), (posOld.Item2 - 1)));

                    // down: left
                    moveTuples.Add(((posOld.Item1 - 1), (posOld.Item2 - 2)));

                    // down: right
                    moveTuples.Add(((posOld.Item1 + 1), (posOld.Item2 - 2)));

                    // Loop through currentGridArray, add matching values to currentPlayerMoves
                    for (int i = 0; i < currentGridArray.Length; ++i)
                    {
                        var currentTuple = ((int, int))currentGridArray[i][0];

                        // If position match and position is NOT empty
                        if (moveTuples.Contains(currentTuple) && (Part)currentGridArray[i][1] != Part.Empty)
                        {
                            // add to array
                            Array.Resize(ref currentPlayerMoves, currentPlayerMoves.Length + 1);
                            currentPlayerMoves[currentPlayerMoves.Length - 1] = new object[] { currentTuple, Direction.Left };
                        }
                    }
                    break;

                // Bishop
                case Part.PlayerOnBishop:
                    // Calculate player bishop moves by row length iteration
                    for (int i = 1; i < rowCount; ++i)
                    {
                        // add positions
                        moveTuples.Add(((posOld.Item1 - i), (posOld.Item2 + i)));
                        moveTuples.Add(((posOld.Item1 + i), (posOld.Item2 + i)));
                        moveTuples.Add(((posOld.Item1 - i), (posOld.Item2 - i)));
                        moveTuples.Add(((posOld.Item1 + i), (posOld.Item2 - i)));
                    }
                    // Loop through currentGridArray, find and add matching values
                    for (int i = 0; i < currentGridArray.Length; ++i)
                    {
                        var currentTuple = ((int, int))currentGridArray[i][0];
                        // If position match and position is NOT empty
                        if (moveTuples.Contains(currentTuple) && (Part)currentGridArray[i][1] != Part.Empty)
                        {
                            // add to array
                            Array.Resize(ref currentPlayerMoves, currentPlayerMoves.Length + 1);
                            currentPlayerMoves[currentPlayerMoves.Length - 1] = new object[] { currentTuple, Direction.Left };
                        }
                    }
                    break;

                // Rook
                case Part.PlayerOnRook:
                    // Calculate player rook moves
                    // Loop through all grid positions that are not currentPlayerPos
                    for (int i = 0; i < currentGridArray.Length; ++i)
                    {
                        // If position not current player position and not empty, analyse it
                        if (((int, int))currentGridArray[i][0] != posOld && (Part)currentGridArray[i][1] != Part.Empty)
                        {
                            var currentTuple = ((int, int))currentGridArray[i][0];
                            // if up or down or left or right of current position
                            if (posOld.Item1 == currentTuple.Item1 || posOld.Item2 == currentTuple.Item2)
                            {
                                // add to array
                                Array.Resize(ref currentPlayerMoves, currentPlayerMoves.Length + 1);
                                currentPlayerMoves[currentPlayerMoves.Length - 1] = new object[] { currentTuple, Direction.Left };
                            }
                        }
                    }
                    break;
            }
            // Return updated moves set
            return currentPlayerMoves;
        }
        // Undo last player move
        public string Undo((int, int) posOld,
            (int, int) posNew,
            object[][] currentGridArray,
            int oldPosIndex,
            int newPosIndex,
            int moveCount,
            Part oldPart,
            Part newPart,
            object[][] currentPlayerPos
            )
        {
            // If at 0 moves, don't undo anything
            if (moveCount == 0)
            {
                return "ERROR: No prior positions left to undo!" + Environment.NewLine;
            }
            // Else undo last action
            else
            {
                // Loop through current grid
                for (int i = 0; i < currentGridArray.Length; ++i)
                {
                    // If old position match, grab it
                    if (((int, int))currentGridArray[i][0] == posOld)
                    {
                        oldPosIndex = i;
                        oldPart = (Part)currentGridArray[i][1];

                    }
                    // Else if new position match, grab it
                    else if (((int, int))currentGridArray[i][0] == posNew)
                    {
                        newPosIndex = i;
                        newPart = (Part)currentGridArray[i][1];
                    }
                }
                // old position -> player
                //  King
                if (oldPart == Part.King)
                {
                    oldPart = Part.PlayerOnKing;
                }
                // Bishop
                else if (oldPart == Part.Bishop)
                {
                    oldPart = Part.PlayerOnBishop;
                }
                // Rook
                else if (oldPart == Part.Rook)
                {
                    oldPart = Part.PlayerOnRook;
                }
                // Knight
                else if (oldPart == Part.Knight)
                {
                    oldPart = Part.PlayerOnKnight;
                }
                // new position -> default
                // PlayerOnKing
                if (newPart == Part.PlayerOnKing)
                {
                    newPart = Part.King;
                }
                // PlayerOnBishop
                else if (newPart == Part.PlayerOnBishop)
                {
                    newPart = Part.Bishop;
                }
                // PlayerOnRook
                else if (newPart == Part.PlayerOnRook)
                {
                    newPart = Part.Rook;
                }
                // PlayerOnKnight
                else if (newPart == Part.PlayerOnKnight)
                {
                    newPart = Part.Knight;
                }
                // Swap parts between old, new
                currentGridArray[oldPosIndex][1] = oldPart;
                currentGridArray[newPosIndex][1] = newPart;
            }
            // nothing returned, if no error
            return null;
        }
        // Move player piece
        public void Move(
            (int, int) posOld,
            (int, int) posNew,
            object[][] currentGridArray,
            int oldPosIndex,
            int newPosIndex,
            Part oldPart,
            Part newPart
            )
        {
            // Loop through current grid
            for (int i = 0; i < currentGridArray.Length; ++i)
            {
                // If old position match, grab it
                if (((int, int))currentGridArray[i][0] == posOld)
                {
                    oldPosIndex = i;
                    oldPart = (Part)currentGridArray[i][1];

                }
                // Else if new position match, grab it
                else if (((int, int))currentGridArray[i][0] == posNew)
                {
                    newPosIndex = i;
                    newPart = (Part)currentGridArray[i][1];
                }
            }
            // old position -> default piece
            // PlayerOnKing
            if (oldPart == Part.PlayerOnKing)
            {
                oldPart = Part.King;
            }
            // PlayerOnBishop
            else if (oldPart == Part.PlayerOnBishop)
            {
                oldPart = Part.Bishop;
            }
            // PlayerOnRook
            else if (oldPart == Part.PlayerOnRook)
            {
                oldPart = Part.Rook;
            }
            // PlayerOnKnight
            else if (oldPart == Part.PlayerOnKnight)
            {
                oldPart = Part.Knight;
            }
            // new position -> player piece
            // King
            if (newPart == Part.King)
            {
                newPart = Part.PlayerOnKing;
            }
            // Bishop
            else if (newPart == Part.Bishop)
            {
                newPart = Part.PlayerOnBishop;
            }
            // Rook
            else if (newPart == Part.Rook)
            {
                newPart = Part.PlayerOnRook;
            }
            // Knight
            else if (newPart == Part.Knight)
            {
                newPart = Part.PlayerOnKnight;
            }
            // Swap part locations
            currentGridArray[oldPosIndex][1] = oldPart;
            currentGridArray[newPosIndex][1] = newPart;
        }

        // Increase moveCount
        public int GetMoveCount(int moveCount, object[][] currentGridArray)
        {
            var partCompletion = 0;
            // Loop through currentGridArray, locate all default values
            for (int i = 0; i < currentGridArray.Length; ++i)
            {
                // If match, add to completion
                if (currentGridArray[i][1] == LoadFile.loadPosArray[i])
                {
                    ++partCompletion;
                }
            }
            // If no moves are made (default board), reset moveCount to 0
            if (partCompletion == currentGridArray.Length)
            {
                moveCount = 0;
            }
            // Else add +1
            else
            {
                ++moveCount;
            }
            return moveCount;
        }
        // Count player wins
        public int GetWinCount(int winCount, object[][] currentPlayerPos)
        {
            // If player on King, +1 to wins
            if ((Part)currentPlayerPos[0][1] == Part.PlayerOnKing)
            {
                ++winCount;
            }
            // Return updated winCount
            return winCount;
        }
        // Count player losses
        public int GetLoseCount(int loseCount, object[][] currentPlayerMoves, object[][] currentPlayerPos)
        {
            // If player moves == 0 && player not on King, +1 to losses
            if (currentPlayerMoves.Length == 0 && (Part)currentPlayerPos[0][1] != Part.PlayerOnKing)
            {
                ++loseCount;
            }
            // Return updated loseCount
            return loseCount;
        }

        // Restart the board by updating the currentGridArray
        public object[][] Restart(object[][] currentGridArray, IFiler filer)
        {
            // load default grid, return updated currentGridArray
            currentGridArray = filer.Load(currentGridArray);
            return currentGridArray;
        }
        // Check if game is finished
        public bool IsFinished(object[][] currentPlayerPos, object[][] currentPlayerMoves)
        {
            // Return true if Player position is PlayerOnKing, or if player has no moves left
            return (((Part)currentPlayerPos[0][1] == Part.PlayerOnKing) || (currentPlayerMoves.Length == 0));
        }
        // Get grid output
        public string ShowGrid
            (
                int rowCount,
                string gridOut,
                object[][] currentGridArray,
                IFileable fileable,
                Dictionary<Part, string> chessSymbols
            )
        {
            // Reset gridOut
            gridOut = "";
            // Loop through currentGridArray
            for (int i = 0; i < currentGridArray.Length; ++i)
            {
                // get tuple coordinates of current index
                var currentTuple = ((int, int))currentGridArray[i][0];
                // get Part from these coordinates
                var currentPart = (Part)fileable.WhatsAt(currentTuple.Item1, currentTuple.Item2, currentGridArray);
                // assign part to gridOut message
                // If end of row, add new line
                if (currentTuple.Item1 == (rowCount - 1))
                {
                    gridOut += chessSymbols[currentPart] + Environment.NewLine;
                }
                // else add as normal
                else
                {
                    gridOut += chessSymbols[currentPart];
                }
            }
            // return updated string for console output
            return gridOut;
        }
        
    }
}
