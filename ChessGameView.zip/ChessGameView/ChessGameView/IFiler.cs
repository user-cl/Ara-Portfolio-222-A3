﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChessGameView
{
    public interface IFiler
    {
        // Update SaveFile.savePosArray to be currentGridArray in use by player
        void Save(object[][] currentGridArray);

        // Load currentGridArray from LoadFile.loadPosArray
        object[][] Load(object[][] currentGridArray);
    }
}
