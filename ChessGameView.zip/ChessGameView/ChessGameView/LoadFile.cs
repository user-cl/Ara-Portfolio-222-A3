﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChessGameView
{
    public static class LoadFile
    {
        public static object[] loadPosArray = new object[]
           {
            // (0, 0) -> (2, 0)
            Part.PlayerOnRook,
            Part.Empty,
            Part.Knight,
            // (0, -1) -> (2, -1)
            Part.Empty,
            Part.Empty,
            Part.Rook,
            // (0, -2) -> (2, -2)
            Part.Bishop,
            Part.Bishop,
            Part.King,
           };
    }

}
