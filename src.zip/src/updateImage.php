<?php
require_once 'myFrame/myFrameHtml.php';
require_once 'siteFunctions/commonFunctions.php';
require_once 'index.php';

	$PG=new masterPage();
    $content="";
	$METHOD=$_SERVER['REQUEST_METHOD'] ;
	$ERROR=null;
    // if posting, update image
	if ($METHOD=='POST') {
        // call changeUserImage() function
        changeUserImage($_POST['chosenUserImage']);
	}
    
    // update page
	$updateImage=new HtmlTemplate('updateImage.html');
	$content.=$updateImage->getHtml(array());	
    
    // catch any errors
	if ($ERROR!=null) {
		$content.='<br/><br/><p>'.$ERROR.'<p>test<br/>';
	}
    
    // confirm HTML page
	$PG->setTitle('Update Profile Image');
	$PG->setContent($content);
   
    print $PG->getHtml();
?>