<?php
include_once ("myFrame/myFrameSql.php");

// the following functions are my own original work

    // function to get table value for column names given <option> type
function typeFilter($userType)
{
    // initial vars
    $table;
    $tableId;
    $tableUsername;
    $tableEmail;
    $tableActive;
    $tablePassword;
    $tablePhoneInt;
    $tablePhoneLocal;
    $tablePhoneNum;
    $tableImgUrl;
    
    // If buyer, set columns to match table name
    if ($userType == 'Buyer')
    {
        $table = 'buyer';
        $tableId = 'buyer_id';
        $tableUsername = 'buyer_username';
        $tableEmail = 'buyer_email';
        $tableActive = 'buyer_active';
        $tablePassword = 'buyer_password';
        $tablePhoneInt = 'buyer_phone_int';
        $tablePhoneLocal = 'buyer_phone_local';
        $tablePhoneNum = 'buyer_phone_num';
        $tableImgUrl = 'buyer_img_url';
    }
    
    // else if seller, set columns to match table name
    else if ($userType == 'Seller')
    {
        $table = 'seller';
        $tableId = 'seller_id';
        $tableUsername = 'seller_username';
        $tableEmail = 'seller_email';
        $tableActive = 'seller_active';
        $tablePassword = 'seller_password';
        $tablePhoneInt = 'seller_phone_int';
        $tablePhoneLocal = 'seller_phone_local';
        $tablePhoneNum = 'seller_phone_num';
        $tableImgUrl = 'seller_img_url';
    }
    
    // else if business Owner, set columns to match table name
    else if ($userType == 'Business Owner')
    {
        $table = 'businessOwner';
        $tableId = 'businessOwner_id';
        $tableUsername = 'businessOwner_username';
        $tableEmail = 'businessOwner_email';
        $tableActive = 'businessOwner_active';
        $tablePassword = 'businessOwner_password';
        $tablePhoneInt = 'businessOwner_phone_int';
        $tablePhoneLocal = 'businessOwner_phone_local';
        $tablePhoneNum = 'businessOwner_phone_num';
        $tableImgUrl = 'businessOwner_img_url';
    }
    
    // else if Agora Master Admin, set columns to match table name
    else if ($userType == 'Agora Master Admin')
    {
        $table='superUser';
        $tableId = 'superUser_id';
        $tableUsername = 'superUser_username';
        $tableEmail = 'superUser_email';
        $tableActive = 'superUser_active';
        $tablePassword = 'superUser_password';
        $tablePhoneInt = 'superUser_phone_int';
        $tablePhoneLocal = 'superUser_phone_local';
        $tablePhoneNum = 'superUser_phone_num';
        $tableImgUrl = 'superUser_img_url';
    }
    
    // return stored array
    return array(
        $table,
        $tableId,
        $tableUsername,
        $tableEmail,
        $tableActive,
        $tablePassword,
        $tablePhoneInt,
        $tablePhoneLocal,
        $tablePhoneNum,
        $tableImgUrl
    );   
}

    // Create query based on user input, get user ID for login
function getUser($userType, $userName, $password)
{
    // connect to db, secure details
    $DB=getDatabase();
    $SALTY='muchsaltiness';
    $SAFE_NAME=sqlSafe($userName);
	$HASHED_PASS = hash('sha256', sqlSafe($password).$SALTY);
    $sql="";
    
    // get type strings filtered
    $typeArr = typeFilter($userType);

    // setup query
    $sql = "select * from ".$typeArr[0]." where ".$typeArr[2]." = '" . $SAFE_NAME . "' and ".$typeArr[5]." = '". $HASHED_PASS ."'";
    
    // save sql result, check if 1 entry found (and return the 1 row)
    $result=$DB->query($sql);
    
    if ($result->size()==1) {
        // return row info
        $row=$result->fetch();
        
        // update $_SESSION variables to hold all details of user
        $_SESSION['userType_table']=$typeArr[0];
        $_SESSION['userType_id']=$typeArr[1];
        $_SESSION['userType_username']=$typeArr[2];
        $_SESSION['userType_email']=$typeArr[3];
        $_SESSION['userType_active']=$typeArr[4];
        $_SESSION['userType_phone_int']=$typeArr[6];
        $_SESSION['userType_phone_local']=$typeArr[7];
        $_SESSION['userType_phone_num']=$typeArr[8];
        $_SESSION['userType_img_url']=$typeArr[9];
        $_SESSION['userType_password']=$typeArr[5];
        
        // setup userInfo on SESSION var
        $_SESSION['userInfo']=$row;
        
        header('Location: myAccountPage.php');
        exit;
        
        // return info
        return $row;
    }
    // else give info (no account found)
    else {
        echo "<p id=\"user-notify\">No account found.</p>";
        return null;
    }
    return null;
} 

// change user image if selection given
function changeUserImage($chosenUserImage)
{
    // initial vars
        // basic sql query
    $DB=getDatabase();
        // sql query
    $SQL = "
    update " . $_SESSION['userType_table'] . "
        set " . $_SESSION['userType_img_url'] . " = 'images/" . $chosenUserImage . ".png'
        where " . $_SESSION['userType_username'] . " = '" . $_SESSION['userInfo'][$_SESSION['userType_username']] . 
        "' and " . $_SESSION['userType_password'] . " = '" . $_SESSION['userInfo'][$_SESSION['userType_password']] . "'
    ";
        // run query
    $result=$DB->query($SQL);
        // update session value
    $_SESSION['userInfo'][$_SESSION['userType_img_url']] = "images/" . $chosenUserImage . ".png";
    
    // go back to account page to see difference
    header('Location: myAccountPage.php');
        exit;
    
    return null;
}

    // create user given POST vals
function createUser(
    $userType,
    $userName,
    $userEmail,
    $userPassword,
    $userPhoneInt,
    $userPhoneLocal,
    $userPhoneNum
)
{
    // initial vars
    $userId;
    // connect to db, secure details
    $db=getDatabase();
    $SALTY='muchsaltiness';
        // these values are compared in db
    $SAFE_NAME=sqlSafe($userName);
    $SAFE_EMAIL=sqlSafe($userEmail);
        // safety protocol; keep password not in plain text (immediately hash)
	$HASHED_PASSWORD = hash('sha256', sqlSafe($userPassword).$SALTY);
        // these are auto generated if new user
    $USER_IMG_URL = 'images/stock-profile.jpg';
    $USER_ACTIVE = 1;
        // custom sql string
    $sql;
        // type array
    $typeArr = typeFilter($userType);
    
    // Check unique values
        // create SQL query with given user types
            // a user is only unique if it has a unique username + email
        $sql="
        select * from ".$typeArr[0]."
        where
            ".$typeArr[2]." = '".$SAFE_NAME."'
        or 
            ".$typeArr[3]." = '".$SAFE_EMAIL."'
        ";
         
        // get result
        $result=$db->query($sql);
        
        // if unique (result 0)
        if ($result->size()==0)
        {
            // get table row count for user type
            $sql="select count(*) from ".$typeArr[0]."";
            $result=$db->query($sql);
                // ensure result worked
            if($result)
            {
                // generate custom ID from row
                $row = $result->fetch();
                    // The new id is +1 to id total for that table
                $newId = (int)$row['count(*)'] + 1;
                
                // create user with details
                $sql="insert into ".$typeArr[0]." (
                    ".$typeArr[1].", 
                    ".$typeArr[2].",
                    ".$typeArr[3].",
                    ".$typeArr[4].",
                    ".$typeArr[5].", 
                    ".$typeArr[6].",
                    ".$typeArr[7].",
                    ".$typeArr[8].",
                    ".$typeArr[9]."
                    )
                values (
                    ".$newId.", 
                    '".$SAFE_NAME."', 
                    '".$SAFE_EMAIL."',
                    ".$USER_ACTIVE.", 
                    '".$HASHED_PASSWORD."',
                    '".$userPhoneInt."',
                    '".$userPhoneLocal."',
                    '".$userPhoneNum."',
                    '".$USER_IMG_URL."'
                )";
                
                // execute SQL, inform user if true
                if($result=$db->query($sql))
                {
                    return true;
                }
                // else return null
                else 
                {
                    return null;
                }
            }
            // else error, return null
            else 
            {
                return null;
            }
        }
         // else not unique (result >= 1)
        else if ($result->size()>=1)
        {
            // notify user, redirect
            return null;
        }
}
    // agora master admin functions
function uploadLogo($ownerId, $logoUrl)
{

    // connect to db, set query
    $DB=getDatabase();
    $SQL="update businessOwner
        set businessOwner_img_url = '".$logoUrl."'
        where businessOwner.businessOwner_id = ".$ownerId."";
    // run query; if it fails, return false
    if (!($result=$DB->query($SQL)))
    {
        return null;
    }
    // else redirect to viewBusinessAccounts.php page
    else {
        header('Location: viewBusinessAccounts.php');
        exit;
    }
}

function connectBusinessAccount($businessOwnerId, $sellerId, $buyerId)
{
    // setup db + sql query
    $DB=getDatabase();
    $sql="
    create or replace view DemoBusinessAccountConnectionView as
        select * from businessOwner, buyer, seller
            where businessOwner.businessOwner_id = ".$businessOwnerId."
                and
            seller.seller_id = ".$sellerId."
                and
            buyer.buyer_id = ".$buyerId.";
    ";
    // run query; if it fails, return false
    if (!($result=$DB->query($sql)))
    {
        return null;
    }
    // else redirect to viewBusinessAccounts.php page
    else {
        header('Location: connections.php');
        exit;
    }
}

function connectBusiness($businessId, $sellerId, $buyerId)
{
    // setup db + sql query
    $DB=getDatabase();
    $SQL="
    create or replace view DemoBusinessConnectionView as
        select * from business, buyer, seller
            where business.business_id = ".$businessId."
                and
            seller.seller_id = ".$sellerId."
                and
            buyer.buyer_id = ".$buyerId.";
    ";
    // run query; if it fails, return false
    if (!($result=$DB->query($SQL)))
    {
        return null;
    }
    // else redirect to viewBusinessAccounts.php page
    else {
        header('Location: connections.php');
        exit;
    }
}

    // buyer functions
function buyProduct($productId, $buyerId)
{
    // setup db + sql query
    $db=getDatabase();
        // search for a product match that has an ACTIVE listing
        $sql="
        select * from product p
            inner join listing l on p.listing_id = l.listing_id
            inner join buyer b on p.buyer_id = b.buyer_id
            where p.product_id = ".$productId."
            and l.listing_active = 1
        ";
        // Run query
        $result=$db->query($sql);
            // if 1 row result, buy it
            if ($result->size()==1) {
                
                // setup db + sql query
                $db=getDatabase();
                    // close the listing as inactive
                    $sql="
                    update listing l
                        set l.listing_active = 0
                        where l.listing_id = ".$productId.";";
                        $result=$db->query($sql);
                return 1;
            }
            // else if no row result, inform user
            else {
                return null;
            }
}

    // seller functions
function newItem(
    $sellerId,
    $listingId,
    $listingName,
    $listingDesc,
    $listingImageUrl,
    $listingQuantity,
    /*
    $buyerId,
    $productId,
    $productName,
    $productDesc,
    $productPrice,
    */
)
{
    // connect to db, set query
    $db=getDatabase();
    $sql="
    insert into listing
        (seller_id,
            listing_id,
            listing_active,
            listing_name,
            listing_desc,
            listing_img_url,
            listing_qty
        ) values (
            ".$sellerId.",
            ".$listingId.",
            1,
            '$listingName',
            '$listingDesc',
            '$listingImageUrl',
            ". $listingQuantity ."
        );";
    
    /* unfinished product sql query
    $sql="
        insert into product
        (listing_id,
            buyer_id,
            product_id,
            product_name,
            product_desc,
            product_price) values (
            ".$listingId.",
            ".$buyerId.",
            ".$productId.",
            '$productName',
            '$productDesc',
            ".$productPrice.");";
   */
        //echo $sql;
    // insert listing, product
        // run query; return null if failed, else continue
    if (!($result=$db->query($sql)))
    {
        return null;
    } else {
        return 1;
    }
}



function readListing($listingId)
{
    // connect to db, set query
    $DB=getDatabase();
    $SQL="select * from listing l
        inner join seller s on l.seller_id = s.seller_id
            where l.listing_id = ".$listingId."";
    
        // run query; return null if failed, else continue
    if (!($result=$DB->query($SQL)))
    {
        return null;
    } else {
        // update $_SESSION variables to hold all details of current listing
        $listingRow = $result->fetch(PDO::FETCH_ASSOC);
        $_SESSION['listing_id']=$listingRow['listing_id'];
        $_SESSION['listing_active']=$listingRow['listing_active'];
        $_SESSION['seller_id']=$listingRow['seller_id'];
        $_SESSION['listing_name']=$listingRow['listing_name'];
        $_SESSION['listing_desc']=$listingRow['listing_desc'];
        $_SESSION['listing_img_url']=$listingRow['listing_img_url'];
        $_SESSION['listing_qty']=$listingRow['listing_qty'];
        return $result;
    }
}

// This code section was taken originally from amit.sarkar@ara.ac.nz, with permission to use being granted.
function getConnection() {
	$HOST = 'localhost' ;
	$DB_USER ='root';
	$DB_PASS ='L055y#m3@ujune';
	$DB_NAME ='agora_db';

    // create a new database object and connect to server
	$DB = new MySQL($HOST, $DB_USER, $DB_PASS, $DB_NAME);
	return $DB; 	
}

function getNewDatabase() {
  
    // create a new database object and connect to server
	$DB = getConnection();
	
	//  drop the database
	try {
		$DB->dropDatabase();
	} catch (exception $ex) {
	}
    
	// create it again
	$DB->createDatabase();

	// select the database
	$DB->selectDatabase();
	return $DB;
}

function getDatabase() {
	$DB = getConnection();
	$DB->selectDatabase();
	return $DB;
}

    // gets a parameter from the URL, or null if not specified
function getFromURL ($key) {
	if (isset($_GET[$key])) {
		return $_GET[$key];
	}
	return null;
}

function sqlSafe ($input) {
	$LINK = mysqli_connect('localhost', 'root', 'L055y#m3@ujune', 'agora_db');
	return mysqli_real_escape_string($LINK, stripslashes($input));
}

?>