<?php
require_once 'myFrame/myFrameHtml.php';
require_once 'siteFunctions/commonFunctions.php';
require_once 'index.php';

	$PG=new masterPage();
    $content="";
	$METHOD=$_SERVER['REQUEST_METHOD'] ;
	$ERROR=null;

    // if post
	if ($METHOD=='POST') {
        $businessId=trim($_POST['businessId']);
        $sellerId=trim($_POST['sellerId']);
        $buyerId=trim($_POST['buyerId']);

        // if any of the values are empty, inform user
        if (($businessId==null) || ($sellerId==null) || ($buyerId==null))
        {
            echo "<p id=\"user-notify\">Not all values were entered. Please try again.</p>";
        }
        // else continue, call connectBusiness();
        else
        {
            $connectResult = connectBusiness($businessId, $sellerId, $buyerId);
        }
	}

    // update page
	$updateImage=new HtmlTemplate('connectBusiness.html');
	$content.=$updateImage->getHtml(array());

    // catch any errors
	if ($ERROR!=null) {
		$content.='<br/><br/><p>'.$ERROR.'<p>test<br/>';
	}

    // confirm HTML page
	$PG->setTitle('Connect Business');
	$PG->setContent($content);

    print $PG->getHtml();
?>