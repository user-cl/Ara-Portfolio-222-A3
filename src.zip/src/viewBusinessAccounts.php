<?php
	include_once 'siteFunctions/commonFunctions.php';
	include_once 'index.php';
	require_once 'myFrame/myFrameTable.php';
	require_once 'myFrame/myFrameHtml.php';
 
    // connect to db
    $PG=new MasterPage();
    $DB = $PG->getDB();
    $content="";
    
    // get query
    $sql="select * from businessOwner";
    
    // load query results
    $listings = $DB->query($sql);
    
        // setup HTML table
        $table=new HtmlTable($listings);
        
        // start adding content
                // <p> start
        $content.="<p id=\"main-text\">";
                // back button
        $content.="<button id=\"button-edit-info\"><a href=\"myAccountPage.php\">Back</a></button>";
            // html table headers
        $content .= "<table id=\"page-table\">
        <th>Owner ID</th> <th>Owner Name</th> <th>Owner Email</th> <th>Logo</th>";
                // assign html buttons for view
        while ($row = $listings->fetch(PDO::FETCH_ASSOC))
        {
            // start row
        $content .= "<tr>";
            // id
        $content .= "<td>{$row['businessOwner_id']}</td>";
            // name
        $content .= "<td>{$row['businessOwner_username']}</td>";
            // email
        $content .= "<td>{$row['businessOwner_email']}</td>";
            // logo
        $content .= "<td>{$row['businessOwner_img_url']}</td>";
            // close row
        $content .= "</tr>";
            
        }
            // close content
        $content.="</table>";
        $content.="</p>";
        
    
	// Add content to master page
	$PG->setTitle('View Business Accounts');
	$PG->setContent($content);	
	print $PG->getHtml();
?>