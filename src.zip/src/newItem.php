<?php
require_once 'myFrame/myFrameHtml.php';
require_once 'siteFunctions/commonFunctions.php';
require_once 'index.php';

	$PG=new masterPage();
    $content="";
	$METHOD=$_SERVER['REQUEST_METHOD'] ;
	$ERROR=null;
    
    // if $_POST
	if ($METHOD=='POST') {
            // listing
            $listingId=trim($_POST['listingId']);
            $listingName=trim($_POST['listingName']);
            $listingDesc=trim($_POST['listingDesc']);
            $listingImageUrl=trim($_POST['listingImageUrl']);
            $listingQuantity=trim($_POST['listingQuantity']);
            // product
            /*
            $buyerId=trim($_POST['buyerId']);
            $productId=trim($_POST['productId']);
            $productName=trim($_POST['productName']);
            $productDesc=trim($_POST['productDesc']);
            $productPrice=trim($_POST['productPrice']);
            */
        
        // if any of the values are empty, inform user
        if (
            // listing
        ($listingId==null) 
        || 
        ($listingName==null) 
        || 
        ($listingDesc==null)
        ||
        ($listingImageUrl==null)
        ||
        ($listingQuantity==null)
        /*
        || // product
        ($buyerId==null) 
        || 
        ($productId==null) 
        || 
        ($productName==null)
        ||
        ($productDesc==null)
        ||
        ($productPrice==null)
        */
        )
        {
            echo "<p id=\"user-notify\">Some values are empty or bad. Please try again.</p>";
        }
        // else continue, call connectBusiness();
        else
        {
            echo "<p id=\"user-notify\">Item created.</p>";
            $newItemResult = newItem(
                $_SESSION['userInfo'][$_SESSION['userType_id']],
                $listingId,
                $listingName,
                $listingDesc,
                $listingImageUrl,
                $listingQuantity,
                /*
                $buyerId,
                $productId,
                $productName,
                $productDesc,
                $productPrice
                */
            );
        }   
	}
    
    // update page
	$UPDATE_IMAGE=new HtmlTemplate('newItem.html');
	$content.=$UPDATE_IMAGE->getHtml(array());	
    
    // catch any errors
	if ($ERROR!=null) {
		$content.='<br/><br/><p>'.$ERROR.'<p>test<br/>';
	}
    
    // confirm HTML page
	$PG->setTitle('New Item');
	$PG->setContent($content);
   
    print $PG->getHtml();
?>