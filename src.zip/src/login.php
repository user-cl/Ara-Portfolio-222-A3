<?php
require_once 'myFrame/myFrameHtml.php';
require_once 'siteFunctions/commonFunctions.php';
require_once 'index.php';

    // translation val (internationalisation)
    $intMi = include 'int/mi-NZ.php';

	$PG=new masterPage();
    $content="";
	$METHOD=$_SERVER['REQUEST_METHOD'] ;
	$ERROR=null;
    // if login sent, get user
	if ($METHOD=='POST') {
        // If name or password empty, tell user
        if ($_POST['userName'] == null || $_POST['password'] == null)
        {
            echo "<p id=\"user-notify\">Not all values were entered. Please try again.</p>";
        }
        
        // Else both not empty, retrieve user in db and redirect to account
        else {
            getUser($_POST['userType'], $_POST['userName'], $_POST['password']);
        }
	}
    
    // update page
	$login=new HtmlTemplate('loginForm.html');
        // Logged in, provide logout msg
	if ($_SESSION!=null) {
        $content = "<p style=\"margin-left: 0.5em;\"><i>" . $intMi['Hello'] . "! Signed in as " . $_SESSION['userInfo'][$_SESSION['userType_username']] . ".</i><button><a href=\"logout.php\">Logout</a></button></p>";
	}
        // logged out, provide login msg
    else
    {
        $content .= "<p style=\"margin-left: 0.5em;\"><i>" . $intMi['Hello'] . "! Not signed in.</i></p>";
        $content.=$login->getHtml(array());
    }
		
	if ($ERROR!=null) {
		$content.='<br/><br/><p>'.$ERROR.'<p>test<br/>';
	}
    
    // confirm HTML page
	$PG->setTitle('Login');
	$PG->setContent($content);
	
    print $PG->getHtml();
?>