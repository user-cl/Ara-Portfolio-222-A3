<?php
require_once 'index.php';
require_once 'myFrame/myFrameHtml.php';
require_once 'myFrame/myFrameTable.php';
// translation val (internationalisation)
    $intMi = include 'int/mi-NZ.php';

	$PG=new MasterPage();
    $content="";
    $sql="";
    $db="";
    
        // if not signed in, redirect to login.php
    if ($_SESSION==null) {
        $login=new HtmlTemplate('loginForm.html');
        $content= "<p style=\"margin-left: 0.5em;\"><i>Kia ora! Not signed in.</i></p>";
        $content.=$login->getHtml(array());	
        $PG->setTitle('Login');
        $PG->setContent($content);
        print $PG->getHtml();
    }
        // else load as normal
	else {
        // begin page
        $content.="<p id=\"main-text\">";
            // businessAccountConnection
            $content.="<h3 id=\"main-text\">Current Business Account Connection</h3>";
                // output data
                    // connect to db
                    $db = $PG->getDB();
                    // get query
                    $sql="select * from DemoBusinessAccountConnectionView";
                    // load query results
                        // check if default empty
                    $members = $db->query($sql);
                    // setup HTML table
                    $table=new HtmlTable($members);
                    // start adding content
                            // <p> start
                    $content.="<p id=\"main-text\">";
                        // html table headers
                    $content .= "<table id=\"page-table\">
                    <th>Business Account Member</th> <th>Buyer Member</th> <th>Seller Member</th>";
                            // assign html buttons for view
                    while ($row = $members->fetch(PDO::FETCH_ASSOC))
                    {
                        // start row
                    $content .= "<tr>";
                        // Business Account member
                    $content .= "<td>{$row['businessOwner_username']}<br>{$row['businessOwner_email']}</td>";
                        // Buyer member
                    $content .= "<td>{$row['buyer_username']}<br>{$row['buyer_email']}</td>";
                        // Seller member
                    $content .= "<td>{$row['seller_username']}<br>{$row['seller_email']}</td>";
                        // close row
                    $content .= "</tr>";
                    }
                        // close content
                    $content.="</table>"; 
                    $content.="</p>";
            
            // businessConnection
            $content.="<h3 id=\"main-text\">Current Business Connection</h3>";
                // output data
                    // connect to db
                    $db = $PG->getDB();
                    // get query
                    $sql="select * from DemoBusinessConnectionView";
                    // load query results
                        // check if default empty
                    $members = $db->query($sql);
                    // setup HTML table
                    $table=new HtmlTable($members);
                    // start adding content
                            // <p> start
                    $content.="<p id=\"main-text\">";
                        // html table headers
                    $content .= "<table id=\"page-table\">
                    <th>Business Member</th> <th>Buyer Member</th> <th>Seller Member</th>";
                            // assign html buttons for view
                    while ($row = $members->fetch(PDO::FETCH_ASSOC))
                    {
                        // start row
                    $content .= "<tr>";
                        // Business member
                    $content .= "<td>{$row['business_name']}<br>{$row['business_email']}</td>";
                        // Buyer member
                    $content .= "<td>{$row['buyer_username']}<br>{$row['buyer_email']}</td>";
                        // Seller member
                    $content .= "<td>{$row['seller_username']}<br>{$row['seller_email']}</td>";
                        // close row
                    $content .= "</tr>";
                    }
                        // close content
                    $content.="</table>"; 
                    $content.="</p>";
                
        
        // close page
        $content.="</p>";
        
		$PG->setTitle('Connections');
		$PG->setContent($content);
		print $PG->getHtml();
	}
?>
