<?php
require_once 'myFrame/myFrameHtml.php';
require_once 'myFrame/myFrameTable.php';
require_once 'siteFunctions/commonFunctions.php';
require_once 'index.php';

// translation val (internationalisation)
    $intMi = include 'int/mi-NZ.php';

// setup new page
$PG=new MasterPage();

    // if not signed in, redirect to login.php
if ($_SESSION==null) {
    $login=new HtmlTemplate('loginForm.html');
    $content= "<p style=\"margin-left: 0.5em;\"><i>Kia ora! Not signed in.</i></p>";
	$content.=$login->getHtml(array());	
    $PG->setTitle('Login');
	$PG->setContent($content);
	print $PG->getHtml();

    // else give account overview
} else {

        // image and details
    $content=
    "
    <p style=\"margin-left: 0.5em;\"><i>" . $intMi['Hello'] . "! Signed in as " . $_SESSION['userInfo'][$_SESSION['userType_username']] .
    ".</i><button><a href=\"logout.php\">Logout</a></button></p>
        <img id=\"page-my-account-img\" src=" . $_SESSION['userInfo'][$_SESSION['userType_img_url']] .">
        <br>
        <h3 id=\"account-name\">Username: " . $_SESSION['userInfo'][$_SESSION['userType_username']] . "</h3>
        <h3 id=\"account-email\">Email: " . $_SESSION['userInfo'][$_SESSION['userType_email']] . "</h3>
        <h3 id=\"account-phone\">Phone Number: " . 
            $_SESSION['userInfo'][$_SESSION['userType_phone_int']] .
            $_SESSION['userInfo'][$_SESSION['userType_phone_local']] .
            $_SESSION['userInfo'][$_SESSION['userType_phone_num']]. "</h3>
    ";
        // user options
    $content.="
    <p id=\"main-text\">
        <button id=\"button-edit-info\"><a href=\"updateImage.php\">Update Profile Image</a></button>
    </p>";
        // conditional - Show seller management if seller
    if(($_SESSION['userType_table'])=='seller')
    {
        // show listings -> read a listing
        $content.="<p id=\"main-text\">
            <button id=\"button-edit-info\"><a href=\"viewListings.php\">View Listings</a></button>
            </p>";
        
        // new item to sell
        $content.="<p id=\"main-text\">
            <button id=\"button-edit-info\"><a href=\"newItem.php\">New Item</a></button>
            </p>";
    }
        // conditional - Show admin management if superuser
    else if(($_SESSION['userType_table'])=='superUser')
    {
        // show business accounts -> upload image to business acount
        $content.="<p id=\"main-text\">
            <button id=\"button-edit-info\"><a href=\"viewBusinessAccounts.php\">View Business Accounts</a></button>
            </p>";
            
        // upload new image url to business account logo
        $content.="<p id=\"main-text\">
            <button id=\"button-edit-info\"><a href=\"uploadLogo.php\">Upload Business Account Logo</a></button>
            </p>";
            
        // select a business account and attach activated buyers/sellers to it.
        $content.="<p id=\"main-text\">
            <button id=\"button-edit-info\"><a href=\"connectBusinessAccount.php\">Connect Business Account</a></button>
            </p>";
    }
    
       // conditional - Show business owner management if business owner
    else if(($_SESSION['userType_table'])=='businessOwner')
    {
        // select a business and attach activated buyers/sellers to it.
        $content.="<p id=\"main-text\">
            <button id=\"button-edit-info\"><a href=\"connectBusiness.php\">Connect Business</a></button>
            </p>";
    }
    
    
       // conditional - Show Buyer purchasing ability if buyer
    else if(($_SESSION['userType_table'])=='buyer')
    {
        // select a business and attach activated buyers/sellers to it.
        $content.="<p id=\"main-text\">
            <button id=\"button-edit-info\"><a href=\"purchaseDeal.php\">Purchase Deal</a></button>
            </p>";
    }
    
    // update title, content
    $PG->setTitle('My Account');
    $PG->setContent($content);
    print $PG->getHtml();  
}
?>