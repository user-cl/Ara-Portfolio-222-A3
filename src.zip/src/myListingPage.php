<?php
require_once 'myFrame/myFrameHtml.php';
require_once 'myFrame/myFrameTable.php';
require_once 'siteFunctions/commonFunctions.php';
require_once 'index.php';

// setup new page
    $PG=new MasterPage();
    $DB = $PG->getDB();
    $content ="";

    // carry over listing id from view listings, use to get listing details in query
    $method=$_SERVER['REQUEST_METHOD'];
    if ($method=='POST')
    {
        $listingResult = readListing($_POST['listing_id']);
        // error catch; if null is returned, inform user
        if ($listingResult==null)
        {
            echo "<p id=\"user-notify\">Error: listing retrieval failed.</p>";
        }
        // else ignore
        else 
        {
        }
    }
    
    // set content
        // back button
    $content.="<button id=\"button-edit-info\"><a href=\"viewListings.php\">Back</a></button>";
    
    
    $content.=
    "<p style=\"margin-left: 0.5em;\"> 
        <h3 id=\"account-name\">Name: " . $_SESSION['listing_name'] . "</h3>
        <img id=\"listing-img\" src=\"" . $_SESSION['listing_img_url'] ."\">
        <h3 id=\"account-name\">Info: " . $_SESSION['listing_desc'] . "</h3>
        <h3 id=\"account-name\">Quantity: " . $_SESSION['listing_qty'] . "</h3>
        <h3 id=\"account-name\">Products:</h3>
        
    ";
        // make query
    $sql="select * from product p
        inner join listing l on p.listing_id = l.listing_id
        inner join buyer b on p.buyer_id = b.buyer_id
        where p.listing_id = ".$_POST['listing_id'].";";
        // run query
    $products=$DB->query($sql);
        // start table
    $table=new HtmlTable($products);
    
    $content.="<table id=\"page-table\">";
    $content.="<th>Product ID</th> <th>Name</th> <th>Info</th> <th>Price</th> <th>Intended Buyer</th>";
        // add table rows
     while ($row = $products->fetch(PDO::FETCH_ASSOC))
    {
        // start row
    $content .= "<tr>";
        // id
    $content .= "<td>{$row['product_id']}</td>";
        // name
    $content .= "<td>{$row['product_name']}</td>";
        // description
    $content .= "<td>{$row['product_desc']}</td>";
        // qty
    $content .= "<td>{$row['product_price']}</td>";
        // intended buyer
    $content .= "<td>{$row['buyer_username']}</td>";
        // close row
    $content .= "</tr>";
    }
    
        // close table
    $content.="</table>";

    // update title, content
    $PG->setTitle('Listing #'.$_SESSION['listing_id'].'');
    $PG->setContent($content);
    print $PG->getHtml();
?>