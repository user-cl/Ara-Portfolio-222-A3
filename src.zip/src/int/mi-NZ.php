<?php
// return following translated words
return [
    'Hello' => 'Kia ora',
];
?>