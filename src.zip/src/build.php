<?php
require_once 'siteFunctions/commonFunctions.php';
require_once 'index.php';
require_once 'myFrame/myFrameSql.php';

	try {
        // Get new database
        $DB=getNewDatabase();
            // Create new tables
                // superUser
        $DB->execute( "create table if not exists superUser
        (
            superUser_id int, 
            superUser_username varchar(55),
            superUser_email varchar(55),
            superUser_active boolean,
            superUser_password varchar(255),
            superUser_phone_int varchar(5),
            superUser_phone_local varchar(5),
            superUser_phone_num varchar(10),
            superUser_img_url varchar(255),
            -- indexes
            index superUser_idx_id (superUser_id),
            primary key (
            superUser_id, 
            superUser_username, 
            superUser_email, 
            superUser_active
            )
        )"
        );
                // businessOwner
        $DB->execute( "create table if not exists businessOwner
        (
        businessOwner_id int, 
        businessOwner_username varchar(55),
        businessOwner_email varchar(55),
        businessOwner_active boolean,
        businessOwner_password varchar(255),
        businessOwner_phone_int varchar(5),
        businessOwner_phone_local varchar(5),
        businessOwner_phone_num varchar(10),
        businessOwner_img_url varchar(255),
        -- indexes
        index businessOwner_idx_id (businessOwner_id),
        primary key (
        businessOwner_id, 
        businessOwner_username,
        businessOwner_email,
        businessOwner_active
        )
        )"
        );
        
                // business
        $DB->execute( "create table if not exists business
        (
        -- FK
        businessOwner_id int,
        -- Other
        business_id int,
        business_name varchar(55),
        business_email varchar(55),
        business_active boolean,
        business_phone_int varchar(5),
        business_phone_local varchar(5),
        business_phone_num varchar(10),
        business_img_url varchar(255),
        -- indexes
        index business_idx_id (business_id),
        primary key (business_id,
        business_name,
        business_email,
        business_active
        )
        )
        "
        );
                // seller
        $DB->execute( "create table if not exists seller
        (
        seller_id int,
        seller_username varchar(55),
        seller_email varchar(55),
        seller_active boolean,
		seller_password varchar(255),
        seller_phone_int varchar(5),
        seller_phone_local varchar(5),
        seller_phone_num varchar(10),
        seller_img_url varchar(255),
        -- indexes
        index seller_idx_id (seller_id),
        primary key (
			seller_id,
            seller_username,
            seller_email,
            seller_active
            )
        )"
        
        );
        
                // listing
        $DB->execute( "create table if not exists listing
        (
        -- FK
        seller_id int,
        -- Other
        listing_id int, 
        listing_active boolean,
        listing_name varchar(55),
        listing_desc varchar(255),
        listing_img_url varchar(255),
        listing_qty int,
        -- indexes
        index listing_idx_id (listing_id),
        primary key (
			listing_id,
            listing_active
            )
        )"
        
        );
                // product
        $DB->execute( "create table if not exists product
        (
        -- FK
        listing_id int,
        buyer_id int,
        -- Other
		product_id int,
        product_name varchar(55),
        product_desc varchar(55),
        product_price decimal(15,2),
        -- indexes
        index product_idx_id (product_id),
        primary key (
        product_id
        )
        )"
        
        );
                // buyer
        $DB->execute( "create table if not exists buyer
        (
        -- Other
		buyer_id int,
        buyer_username varchar(55),
        buyer_email varchar(55),
        buyer_active boolean,
        buyer_password varchar(255),
        buyer_phone_int varchar(5),
        buyer_phone_local varchar(5),
        buyer_phone_num varchar(10),
        buyer_img_url varchar(255),
        -- indexes
        index buyer_idx_id (buyer_id),
        primary key (
			buyer_id,
            buyer_username,
            buyer_email,
            buyer_active
            )
        )"
        );
            
            // alter tables (foreign keys)
                // business
        $DB->execute(
            "alter table business
                add foreign key (businessOwner_id) references businessOwner(businessOwner_id)"
        );
                // listing
        $DB->execute(
            "alter table listing
                add foreign key (seller_id) references seller(seller_id)"
        );
                // product fk
        $DB->execute(
            "alter table product
                add foreign key (listing_id) references listing(listing_id)"
        );
                // product fk #2
        $DB->execute(
            "alter table product
                add foreign key (buyer_id) references buyer(buyer_id)"
        );
            
            // create views
                // superUser
        $DB->execute(
            "create or replace view superUser_view as select * from superUser"
        );
                // businessOwner
        $DB->execute(
            "create or replace view businessOwner_view as select * from businessOwner"
        );
                // business
        $DB->execute(
            "create or replace view business_view as select * from business"
        );
                // seller
        $DB->execute(
            "create or replace view seller_view as select * from seller"
        );
                // listing
        $DB->execute(
            "create or replace view listing_view as select * from listing"
        );
                // product
        $DB->execute(
            "create or replace view product_view as select * from product"
        );
                // buyer
        $DB->execute(
            "create or replace view buyer_view as select * from buyer"
        );
            // set up initial DemoBusinessAccountConnectionView
        $DB->execute(
            "create or replace view DemoBusinessAccountConnectionView as
                select * from businessOwner, buyer, seller
                    where businessOwner.businessOwner_id = 1
                        and
                    seller.seller_id = 1
                        and
                    buyer.buyer_id = 1;"
        );
            // set up initial DemoBusinessConnectionView
        $DB->execute(
            "create or replace view DemoBusinessConnectionView as
                select * from business, buyer, seller
                    where business.business_id = 1
                        and
                    seller.seller_id = 1
                        and
                    buyer.buyer_id = 1;"
        );
        
            // Bulk insert
                // superUser
        $DB->execute(
            "load data infile \"C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/superUser.csv\"
		into table superUser
		fields terminated by \",\" 
		lines terminated by \"\n\"
		ignore 1 rows;"
        );
                // seller
        $DB->execute(
            "load data infile \"C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/seller.csv\"
		into table seller
		fields terminated by \",\" 
		lines terminated by \"\n\"
		ignore 1 rows;"
        );
                // listing
        $DB->execute(
            "load data infile \"C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/listing.csv\"
		into table listing
		fields terminated by \",\" 
		lines terminated by \"\n\"
		ignore 1 rows;"
        );
                // buyer
        $DB->execute(
            "load data infile \"C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/buyer.csv\"
		into table buyer
		fields terminated by \",\" 
		lines terminated by \"\n\"
		ignore 1 rows;"
        );
                // product
        $DB->execute(
            "load data infile \"C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/product.csv\"
		into table product
		fields terminated by \",\" 
		lines terminated by \"\n\"
		ignore 1 rows;"
        );
                // businessOwner
        $DB->execute(
            "load data infile \"C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/businessOwner.csv\"
		into table businessOwner
		fields terminated by \",\" 
		lines terminated by \"\n\"
		ignore 1 rows;"
        );
                // business
        $DB->execute(
            "load data infile \"C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/business.csv\"
		into table business
		fields terminated by \",\" 
		lines terminated by \"\n\"
		ignore 1 rows;"
        );

	} catch (exception $ex) {
		print $ex;
	}
?>
