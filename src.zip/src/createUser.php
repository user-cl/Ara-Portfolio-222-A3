<?php
require_once 'myFrame/myFrameHtml.php';
require_once 'siteFunctions/commonFunctions.php';
require_once 'index.php';

    // translation val (internationalisation)
    $intMi = include 'int/mi-NZ.php';

	$PG=new masterPage();
    $content="";
	$METHOD=$_SERVER['REQUEST_METHOD'] ;
	$ERROR=null;
    
    // send vals to createUser() if posted
	if ($METHOD=='POST') {
            // values
        $_POST['userType'];
        $_POST['userName'];
        $_POST['userEmail'];
        $_POST['userPassword'];
        $_POST['userPhoneInt'];
        $_POST['userPhoneLocal'];
        $_POST['userPhoneNum'];
        
        // error check
            // if username empty or bad, throw error
        if (trim($_POST['userName'])==null || strlen(trim($_POST['userName']))>55)
        {
            echo "<p id=\"user-notify\">Username empty or bad value. Please try again.</p>";
        }
            // else if userEmail empty or bad, throw error
        else if (trim($_POST['userEmail'])==null || strlen(trim($_POST['userEmail']))>55)
        {
            echo "<p id=\"user-notify\">userEmail empty or bad value. Please try again.</p>";
        }
            // else if userPassword empty or bad, throw error
        else if (trim($_POST['userPassword'])==null || strlen(trim($_POST['userPassword']))>255)
        {
            echo "<p id=\"user-notify\">userPassword empty or bad value. Please try again.</p>";
        }
            // else if userPhoneInt empty or bad, throw error
        else if (trim($_POST['userPhoneInt'])==null || strlen(trim($_POST['userPhoneInt']))>5)
        {
            echo "<p id=\"user-notify\">userPhoneInt empty or bad value. Please try again.</p>";
        }
         // else if userPhoneLocal empty or bad, throw error
        else if (trim($_POST['userPhoneLocal'])==null || strlen(trim($_POST['userPhoneLocal']))>5)
        {
            echo "<p id=\"user-notify\">userPhoneLocal empty or bad value. Please try again.</p>";
        }
            // else if userPhoneNum empty or bad, throw error
        else if (trim($_POST['userPhoneNum'])==null || strlen(trim($_POST['userPhoneNum']))>10)
        {
            echo "<p id=\"user-notify\">userPhoneNum empty or bad value. Please try again.</p>";
        }
            // else call createUser()
        else {
            // get result
            $createUserResult = createUser(
                $_POST['userType'], 
                $_POST['userName'], 
                $_POST['userEmail'], 
                $_POST['userPassword'], 
                $_POST['userPhoneInt'],
                $_POST['userPhoneLocal'],
                $_POST['userPhoneNum']
            );
                
                // if null, inform
            if (($createUserResult) == null)
            {
                echo "<p id=\"user-notify\">Sorry! A user with that Username, Email, or Phone Number already exists. Please try something else.</p>";
            }
                // else if success, inform
            else
            {
                $content.= "<p id=\"user-notify\"User created.</p>";
            }
        }
	}
    
    // update page
	$createUser=new HtmlTemplate('createUser.html');
        // Logged in, provide logout msg
	if ($_SESSION!=null) {
        $content = "<p style=\"margin-left: 0.5em;\"><i>" . $intMi['Hello'] . "! Signed in as " . $_SESSION['userInfo'][$_SESSION['userType_username']] .
        ".</i><button><a href=\"logout.php\">Logout</a></button></p>";
	}
        // logged out, provide login msg
    else
    {
        $content .= "<p style=\"margin-left: 0.5em;\"><i>" . $intMi['Hello'] . "! Not signed in.</i></p>";
        $content.=$createUser->getHtml(array());
    }
    // error catch
	if ($ERROR!=null) {
		$content.='<br/><br/><p>'.$ERROR.'<p>test<br/>';
	}
    
    // confirm HTML page
	$PG->setTitle('Create User');
	$PG->setContent($content);
	
    print $PG->getHtml();
?>

