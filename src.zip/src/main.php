<?php

require_once 'index.php';

    // translation val (internationalisation)
    $intMi = include 'int/mi-NZ.php';

    // new page instance
	$PG=new MasterPage();
    $content ="";
    
    // login panel conditional
        // Logged in, provide logout msg + option
	if ($_SESSION!=null) {
        $content .= "<p style=\"margin-left: 0.5em;\"><i>" . $intMi['Hello'] . "! Signed in as " . $_SESSION['userInfo'][$_SESSION['userType_username']] . ".</i><button><a href=\"logout.php\">Logout</a></button></p>";
	}
        // logged out, provide login msg + option
    else
    {
        $content .= "<p style=\"margin-left: 0.5em;\"><i>" . $intMi['Hello'] . "! Not signed in.</i><button><a href=\"login.php\">Login</a></button></p>";
    }
    // main page content
    $content.='
        <p id="main-text">
            Welcome to Agora! We are a free marketplace for New Zealanders eager to trade and sell at fair, agreed upon prices.
        </p>
        <img id="main-img" src="images/home-stock.jpg"/>
    ';
               
    $PG->setTitle('Home');
    $PG->setContent($content);
    print $PG->getHtml();
?>