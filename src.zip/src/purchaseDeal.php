<?php
require_once 'myFrame/myFrameHtml.php';
require_once 'siteFunctions/commonFunctions.php';
require_once 'index.php';

	$PG=new masterPage();
    $content="";
	$METHOD=$_SERVER['REQUEST_METHOD'] ;
	$ERROR=null;
    
    // if post
	if ($METHOD=='POST') {
        
            // $_POST vals
        $productId=trim($_POST['productId']);
        
        // if value empty, inform user
        if (($productId==null))
        {
            echo "<p id=\"user-notify\">Value not entered. Please try again.</p>";
        }
        // else continue, call buyProduct();
        else
        {
            $buyResult = buyProduct($productId, $_SESSION['userInfo'][$_SESSION['userType_id']]);
            // if result bad, inform user
            if ($buyResult == null)
            {
                echo "<p id=\"user-notify\">There was no designated purchase for you under that ID.</p>";
            }
            // else ignore
            else {
                echo "<p id=\"user-notify\">Purchase complete!
                The seller has been instructed to ship the goods and has temporarily closed their listing until further renewal.</p>";
            }            
        }   
	}
    
    // update page
	$UPDATE_IMAGE=new HtmlTemplate('purchaseDeal.html');
	$content.=$UPDATE_IMAGE->getHtml(array());	
    
    // catch any errors
	if ($ERROR!=null) {
		$content.='<br/><br/><p>'.$ERROR.'<p>test<br/>';
	}
    
    // confirm HTML page
	$PG->setTitle('Buy a Product');
	$PG->setContent($content);
   
    print $PG->getHtml();
?>