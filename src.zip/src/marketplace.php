<?php
require_once 'index.php';
require_once 'myFrame/myFrameHtml.php';
require_once 'myFrame/myFrameTable.php';
// translation val (internationalisation)
    $intMi = include 'int/mi-NZ.php';

	$PG=new MasterPage();
    $content="";
    $sql="";
    $db="";
    
        // if not signed in, redirect to login.php
    if ($_SESSION==null) {
        $login=new HtmlTemplate('loginForm.html');
        $content= "<p style=\"margin-left: 0.5em;\"><i>Kia ora! Not signed in.</i></p>";
        $content.=$login->getHtml(array());	
        $PG->setTitle('Login');
        $PG->setContent($content);
        print $PG->getHtml();
    }
        // else load as normal
	else {
        // else if not buyer, give logout option to encourage they login as buyer
        if(($_SESSION['userType_table'])=='buyer')
        {
                // has logout option (because marketplace only accessible if signed in
		$content.=
            "<p style=\"margin-left: 0.5em;\"><i>" . $intMi['Hello'] . "! Signed in as " . $_SESSION['userInfo'][$_SESSION['userType_username']] .
            ".</i><button><a href=\"logout.php\">Logout</a></button></p>
            <p id=\"main-text\">View current listings.</p>
            ";
            // load all available listings
                // connect to db
                $db = $PG->getDB();
                // get query
                $sql="select * from listing l inner join seller s on l.seller_id = s.seller_id where l.listing_active = 1;";
                // load query results
                $listings = $db->query($sql);
                // setup HTML table
                $table=new HtmlTable($listings);
                // start adding content
                        // <p> start
                $content.="<p id=\"main-text\">";
                    // html table headers
                $content .= "<table id=\"page-table\">
                <th>Seller</th> <th>Listing</th> <th>Info</th> <th>QTY</th> <th>Inspect</th>";
                        // assign html buttons for view
                while ($row = $listings->fetch(PDO::FETCH_ASSOC))
                {
                    // start row
                $content .= "<tr>";
                    // seller name
                $content .= "<td>{$row['seller_username']}</td>";
                    // listing name
                $content .= "<td>{$row['listing_name']}</td>";
                    // desc
                $content .= "<td>{$row['listing_desc']}</td>";
                    // qty
                $content .= "<td>{$row['listing_qty']}</td>";
                
                    // read -> inspect individual listing
                $content .= "
                <td>
                    <form action=\"buyerListingPage.php\" method=\"POST\">
                        <label for=\"listing_id\">View</label>
                        <input  type=\"submit\" name=\"listing_id\" value=\"{$row['listing_id']}\">
                    </form>
                </td>
                ";
                    // close row
                $content .= "</tr>";
                    
                }
                    // close content
                $content.="</table>";
                $content.="</p>";
        }
        // else if not buyer, give logout option to encourage they login as buyer
        else {
            // logout message
            $content.="<p style=\"margin-left: 0.5em;\"><i>" . $intMi['Hello'] . "! Signed in as " . $_SESSION['userInfo'][$_SESSION['userType_username']] .
            ".</i><button><a href=\"logout.php\">Logout</a></button></p>";
            // marketplace message
            $content.="<p id=\"main-text\">Sorry! Only buyers can access the marketplace!</p>";
        }
        
				   
		$PG->setTitle('Marketplace');
		$PG->setContent($content);
		print $PG->getHtml();
	}
?>