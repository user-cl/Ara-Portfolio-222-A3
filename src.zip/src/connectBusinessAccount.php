<?php
require_once 'myFrame/myFrameHtml.php';
require_once 'siteFunctions/commonFunctions.php';
require_once 'index.php';

	$PG=new masterPage();
    $content="";
	$METHOD=$_SERVER['REQUEST_METHOD'] ;
	$ERROR=null;
    
    // if post
	if ($METHOD=='POST') {
        $businessOwnerId=trim($_POST['businessOwnerId']);
        $sellerId=trim($_POST['sellerId']);
        $buyerId=trim($_POST['buyerId']);
        
        // if any of the values are empty, inform user
        if (($businessOwnerId==null) || ($sellerId==null) || ($buyerId==null))
        {
            echo "<p id=\"user-notify\">Not all values were entered. Please try again.</p>";
        }
        // else continue, call connectBusinessAccount();
        else
        {
            $connectResult = connectBusinessAccount($businessOwnerId, $sellerId, $buyerId);
        }   
	}
    
    // update page
	$updateImage=new HtmlTemplate('connectBusinessAccount.html');
	$content.=$updateImage->getHtml(array());	
    
    // catch any errors
	if ($ERROR!=null) {
		$content.='<br/><br/><p>'.$ERROR.'<p>test<br/>';
	}
    
    // confirm HTML page
	$PG->setTitle('Connect Business Account');
	$PG->setContent($content);
   
    print $PG->getHtml();
?>