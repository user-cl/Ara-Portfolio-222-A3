<?php
require_once 'myFrame/myFrameHtml.php';
require_once 'siteFunctions/commonFunctions.php';
require_once 'index.php';

	$PG=new masterPage();
    $content="";
	$METHOD=$_SERVER['REQUEST_METHOD'] ;
	$ERROR=null;
    // if post, ensure both values good before sending to uploadLogo()
	if ($METHOD=='POST') {
        $ownerId=trim($_POST['ownerId']);
        $logoUrl=trim($_POST['logoUrl']);
        
        // if either are empty, inform user
        if ($ownerId==null || $logoUrl==null)
        {
            echo "<p id=\"user-notify\">Not all values were entered. Please try again.</p>";
        }
        // else continue, call uploadLogo();
        else
        {
            $uploadResult = uploadLogo($ownerId, $logoUrl);
        }
        
	}
    
    // update page
	$updateImage=new HtmlTemplate('uploadLogo.html');
	$content.=$updateImage->getHtml(array());	
    
    // catch any errors
	if ($ERROR!=null) {
		$content.='<br/><br/><p>'.$ERROR.'<p>test<br/>';
	}
    
    // confirm HTML page
	$PG->setTitle('Upload Business Account Logo');
	$PG->setContent($content);
   
    print $PG->getHtml();
?>