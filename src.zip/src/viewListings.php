<?php
	include_once 'siteFunctions/commonFunctions.php';
	include_once 'index.php';
	require_once 'myFrame/myFrameTable.php';
	require_once 'myFrame/myFrameHtml.php';

        // new page
	$PG = new MasterPage();
        // connect to DB, get result from seller products
	$DB = $PG->getDB();
    
	$SQL="select 
        p.listing_id, 
        l.listing_name, 
        l.listing_desc, 
        l.listing_qty 
		from product p
	inner join listing l on p.product_id = l.listing_id
    inner join seller s on l.seller_id = s.seller_id
    where s.seller_username='".$_SESSION['userInfo'][$_SESSION['userType_username']]."' and l.listing_active = 1;;";
    
	$listings = $DB->query($SQL);
	
	// Format listings as HTML
	$table=new HtmlTable($listings);
    
        // start adding content
            // <p> start
    $content="<p id=\"main-text\">";
            // back button
    $content.="<button id=\"button-edit-info\"><a href=\"myAccountPage.php\">Back</a></button>";
        // html table headers
    $content .= "<table id=\"page-table\">
    <th>Listing ID</th> <th>Name</th> <th>Info</th> <th>QTY</th> <th>Inspect</th>";
            // assign html buttons for view
    while ($row = $listings->fetch(PDO::FETCH_ASSOC))
    {
        // start row
    $content .= "<tr>";
        // id
    $content .= "<td>{$row['listing_id']}</td>";
        // name
    $content .= "<td>{$row['listing_name']}</td>";
        // description
    $content .= "<td>{$row['listing_desc']}</td>";
        // qty
    $content .= "<td>{$row['listing_qty']}</td>";
    
        // read -> inspect individual listing
    $content .= "
    <td>
        <form action=\"myListingPage.php\" method=\"POST\">
            <label for=\"listing_id\">Read</label>
            <input  type=\"submit\" name=\"listing_id\" value=\"{$row['listing_id']}\">
        </form>
    </td>
    ";
        // close row
    $content .= "</tr>";
        
    }
        // close content
    $content.="</table>";
	$content.="</p>";
    
	// Add content to master page
	$PG->setTitle('My Listings');
	$PG->setContent($content);	
	print $PG->getHtml();
?>
